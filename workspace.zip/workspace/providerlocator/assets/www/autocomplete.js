﻿/// <reference path="http://ajax.microsoft.com/ajax/jQuery/jquery-1.8.2-vsdoc.js" />

$(document).ready(function ()
{
    InitAutoComplete();
});

//This function is called by the autocomplete for the county, state type ahead to format the word "county" inline 
function FormatCountyMatches(row, i, n)
{
    if (row.County != "")
    {
        if (i > 0)
            return row.Display.replace(" county", "<i> county</i>").replace(" parish", "<i> parish</i>"); //make "county" and "parish" italic to show it's not part of the data
        else
            return row.Display; //text to be placed in input box can't have html
    }
    else
    {
        return row.Display;
    }
}

function InitAutoComplete()
{
    try
    {
        if ($(".address-type-ahead").length > 0)
        {
            var autoCompleteOptions =
            {
                cacheLength: 1,
                scroll: true,
                minChars: 1,
                scrollHeight: 200,
                max: 10,
                autoFill: true,
                selectFirst: true,
                delay: 400,
                width: 0,
                mustMatch: false,
                dataType: "jsonp", /* For cross domain request this is changed from json to jsonp */
                parse: function (data)
                {
                    var rows = new Array();
                    for (var i = 0; i < data.length; i++)
                    {
                        rows[i] =
                                {
                                    data: data[i],
                                    value: data[i].Display,
                                    result: data[i].Display
                                };
                    }
                    return rows;
                },
                formatItem: function (row, i, n)
                {
                    return FormatCountyMatches(row, i, n);
                }
            };

            $(".address-type-ahead").autocomplete(dataServer + "autocomplete", autoCompleteOptions);

            function ProcessAddressResult(event, data, formatted)
            {
                if (data)
                {
                    $(".address-type-ahead").val(formatted);
                    $(".city").val(data["City"]).trigger("change");
                    $(".county").val(data["County"]).trigger("change");
                    $(".state").val(data["State"]).trigger("change");
                    $(".zip").val(data["Zip"]).trigger("change");
                }
                else
                {
                    $(".address-type-ahead").val("");
                    $(".city").val("").trigger("change");
                    $(".county").val("").trigger("change");
                    $(".state").val("").trigger("change");
                    $(".zip").val("").trigger("change");
                }
                $(".address-type-ahead").trigger("change");
            }
            $(".address-type-ahead").result(ProcessAddressResult);
            function ProcessAddressKeyDown(event)
            {
                if (DoesKeyAlterTextField(event.which))
                {
                    $('.city').val('').trigger('change');
                    $('.county').val('').trigger('change');
                    $('.state').val('').trigger('change');
                    $('.zip').val('').trigger('change');
                }
            }

            $('.address-type-ahead').keydown(ProcessAddressKeyDown);

        }
    }
    catch (e) { }
}

function DoesKeyAlterTextField(keycode)
{
    var isSpecial = IsSpecialKey(keycode)
    var doesAlter = true;
    if (isSpecial)
    {
        // Doesn't matter whether shift key is pressed to determin this so we can always pass false.
        var key = GetKeyDescription(keycode, false);

        switch (key)
        {
            case "BACKSPACE":
            case "DELETE":
                doesAlter = true; break;
            default: doesAlter = false; break;
        }
    }

    return doesAlter;
}

function IsSpecialKey(keycode)
{
    // No special keys require shift to be held so we can always pass false.
    var key = GetKeyDescription(keycode, false);
    var isSpecial = false;
    switch (key)
    {
        case 'ALT':
        case 'BACKSPACE':
        case 'CAPS_LOCK':
        case 'COMMAND':
        case 'CONTROL':
        case 'DELETE':
        case 'DOWN':
        case 'END':
        case 'ENTER':
        case 'ESCAPE':
        case 'HOME':
        case 'INSERT':
        case 'LEFT':
        case 'MENU':
        case 'ENTER':
        case 'PAGE_DOWN':
        case 'PAGE_UP':
        case 'NUM_LOCK':
        case 'SCROLL_LOCK':
        case 'PAUSE_BREAK':
        case 'RIGHT':
        case 'SHIFT':
        case 'TAB':
        case 'UP':
        case 'WINDOWS':
        case 'F1':
        case 'F2':
        case 'F3':
        case 'F4':
        case 'F5':
        case 'F6':
        case 'F7':
        case 'F8':
        case 'F9':
        case 'F10':
        case 'F11':
        case 'F12':
            isSpecial = true; break;
        default: break;
    }
    return isSpecial
}

function GetKeyDescription(keycode, shiftKey)
{
    var description = undefined;
    switch (keycode)
    {
        case 8: description = 'BACKSPACE'; break;
        case 9: description = 'TAB'; break;
        case 13: description = 'ENTER'; break;
        case 16: description = 'SHIFT'; break;
        case 17: description = 'CONTROL'; break;
        case 18: description = 'ALT'; break;
        case 19: description = 'PAUSE_BREAK'; break;
        case 20: description = 'CAPS_LOCK'; break;
        case 27: description = 'ESCAPE'; break;
        case 32: description = ' '; break;
        case 33: description = 'PAGE_UP'; break;
        case 34: description = 'PAGE_DOWN'; break;
        case 35: description = 'END'; break;
        case 36: description = 'HOME'; break;
        case 37: description = 'LEFT'; break;
        case 38: description = 'UP'; break;
        case 39: description = 'RIGHT'; break;
        case 40: description = 'DOWN'; break;
        case 45: description = 'INSERT'; break;
        case 46: description = 'DELETE'; break;
        case 48: (shiftKey ? description = ')' : description = '0'); break;
        case 49: (shiftKey ? description = '!' : description = '1'); break;
        case 50: (shiftKey ? description = '@' : description = '2'); break;
        case 51: (shiftKey ? description = '#' : description = '3'); break;
        case 52: (shiftKey ? description = '$' : description = '4'); break;
        case 53: (shiftKey ? description = '%' : description = '5'); break;
        case 54: (shiftKey ? description = '^' : description = '6'); break;
        case 55: (shiftKey ? description = '&' : description = '7'); break;
        case 56: (shiftKey ? description = '*' : description = '8'); break;
        case 57: (shiftKey ? description = '(' : description = '9'); break;
        case 91: description = 'WINDOWS'; break;
        case 93: description = 'MENU'; break;
        case 96: description = '0'; break;
        case 97: description = '1'; break;
        case 98: description = '2'; break;
        case 99: description = '3'; break;
        case 100: description = '4'; break;
        case 101: description = '5'; break;
        case 102: description = '6'; break;
        case 103: description = '7'; break;
        case 104: description = '8'; break;
        case 105: description = '9'; break;
        case 106: description = '*'; break;
        case 107: description = '+'; break;
        case 108: description = 'ENTER'; break;
        case 109: description = '-'; break;
        case 110: description = '.'; break;
        case 111: description = '/'; break;
        case 112: description = 'F1'; break;
        case 113: description = 'F2'; break;
        case 114: description = 'F3'; break;
        case 115: description = 'F4'; break;
        case 116: description = 'F5'; break;
        case 117: description = 'F6'; break;
        case 118: description = 'F7'; break;
        case 119: description = 'F8'; break;
        case 120: description = 'F9'; break;
        case 121: description = 'F10'; break;
        case 122: description = 'F11'; break;
        case 123: description = 'F12'; break;
        case 144: description = "NUM_LOCK"; break;
        case 145: description = 'SCROLL_LOCK'; break;
        case 186: (shiftKey ? description = ':' : description = ';'); break;
        case 187: (shiftKey ? description = '+' : description = '='); break;
        case 188: (shiftKey ? description = '<' : description = ','); break;
        case 189: (shiftKey ? description = '_' : description = '-'); break;
        case 190: (shiftKey ? description = '>' : description = '.'); break;
        case 191: (shiftKey ? description = '?' : description = '/'); break;
        case 192: (shiftKey ? description = '~' : description = '`'); break;
        case 219: (shiftKey ? description = '{' : description = '['); break;
        case 220: (shiftKey ? description = '|' : description = '\\'); break;
        case 221: (shiftKey ? description = '}' : description = ']'); break;
        case 222: (shiftKey ? description = '\"' : description = '\''); break;
        default: break;
    }

    if (description == undefined)
    {
        if (shiftKey)
            description = String.fromCharCode(keycode).toUpperCase();
        else
            description = String.fromCharCode(keycode).toLowerCase();
    }

    return description;
}
