﻿/// <reference path="http://ajax.microsoft.com/ajax/jQuery/jquery-1.8.2-vsdoc.js" />

/* ENSURE URL TO DATA IS SET WHEN PACKING FOR PHONEGAP */
var dataServer = "http://ameritas.mobiledev.prismisp.com/api/";
var mapUrl = null;
var searchResults = null;
var profile = null;
var specialties = null;
var languages = null;

function SetDataServer()
{
    if (dataServer) return; //Don't try to determine the server if it has been set

    if (window.location.toString().toLowerCase().indexOf(".stg.") > -1)
        dataServer = "http://ameritas-dental.stg.prismisp.com/api/";
    else if (window.location.toString().toLowerCase().indexOf(".qa.") > -1 || window.location.toString().toLowerCase().indexOf(".design.") > -1)
        dataServer = "http://ameritas-dental.qa.prismisp.com/api/";
    else if (window.location.toString().toLowerCase().indexOf(".test.") > -1)
        dataServer = "http://ameritas-dental.test.prism.local/api/";
    else 
        dataServer = window.location.toString().substring(0, window.location.toString().toLowerCase().indexOf("ameritas")) + "ameritas/api/"; 
}

function SetMapUrl()
{
    if (mapUrl) return; //Don't try to determine the mobile device if mapUrl has been set

    if (navigator.userAgent.match(/(iPad|iPhone|iPod)/i))
        mapUrl = "maps:q=";
    else
        mapUrl = "https://maps.google.com/?q=";
}

function GetData(url, data, successCallback, errorCallback)
{
    ShowLoadingMsg();
    $.getJSON(dataServer + url + "?callback=?", data, function (data)
    {
        if (data.ErrorMessage)
        {
		CloseLoadingMsg();
		alert(data.ErrorMessage);
        }
        else if (successCallback)
        {
		CloseLoadingMsg();
		(successCallback(data));
            
        }
    }).error(errorCallback); 
}

function GetDataNoForm(url, successCallback, errorCallback)
{
    ShowLoadingMsg();
    $.getJSON(url, function (response)
    {       
    
        if (response.ErrorMessage)
        {
		CloseLoadingMsg();
		alert(response.ErrorMessage);
        }
        else if (successCallback)
        {
		CloseLoadingMsg();
		(successCallback(response));
            
        }
    }).error(errorCallback); 
     
}


function ShowLoadingMsg()
{
    $.mobile.showPageLoadingMsg();
}

function CloseLoadingMsg()
{
    $.mobile.hidePageLoadingMsg();
}

function DetectLanguage()
{
    if (specialties && languages)
    {
        GetData("browser", null, function (data) { if (data.Language == "spanish") Translate(); }, ShowError);
    }
}

function ShowError(jqXHR, textStatus, errorThrown)
{
    if (errorThrown)
        alert(errorThrown);

    CloseLoadingMsg();
}

function SendPDFEmail(form)
{
    var data = form.serialize();
    if (IsSpanish())
        data += "&culture=es-US";
    GetData("directory", data, CloseLoadingMsg, ShowError);
}

function LoadNetworks()
{
    GetData("network", null, FillNetworks, ShowError);
}

function LoadSpecialties()
{
    if (specialties)
        FillSpecialties(specialties);
    else
        GetData("specialty", null, FillSpecialties, ShowError);
}

function LoadLanguages()
{
    if (languages)
        FillLanguages(languages);
    else
        GetData("language", null, FillLanguages, ShowError);
}

function FillNetworks(data)
{
	var cbo = $("#network-select");
	//var output = ["<option value=' ' data-language='Residentes de CA: seleccionar red'>CA Residents Select a Network</option>"];
	var output = [""];

	var j = 0;

	for (var i = 0; i < data.length; i++)
	{
		output[i + 1] = "<option value=\"" + data[i].ID + "\">" + data[i].Description + "</option>";
	}
	cbo.html(output.join(''));
	cbo = $("#network");
	cbo.html(output.join(''));
}

function FillSpecialties(data)
{
    if (!specialties)
        specialties = data;

    var cbo = $("#specialty");
    var output = ["<option value=' '>" + (IsSpanish() ? "Todas las especialidades" : "All Specialties") + "</option>"];

    data = SortBy(data, (IsSpanish() ? "Spanish" : "English"));

    for (var i = 0; i < data.length; i++)
    {
        output[i + 1] = "<option value=\"" + data[i].ID + "\" >" + (IsSpanish() ? data[i].Spanish : data[i].English) + "</option>";
    }
    cbo.html(output.join(''));
    DetectLanguage();
}

function FillLanguages(data)
{
    if (!languages)
        languages = data;

    var cbo = $("#language");
    var output = ["<option value=' ' data-placeholder='true'>" + (IsSpanish() ? "Todos los idiomas" : "All Languages") + "</option>"];
    
    data = SortBy(data, (IsSpanish() ? "Spanish" : "English"));

    for (var i = 0; i < data.length; i++)
    {
        output[i + 1] = "<option value=\"" + data[i].ID + "\">" + (IsSpanish() ? data[i].Spanish : data[i].English) + "</option>";
    }
    cbo.html(output.join(''));
    DetectLanguage();
}

function SortBy(data, property)
{
    return data.sort(function (a, b) { return (a[property] > b[property] ? 1 : -1); });
}

var GEOCODE_SERVICE= "http://maps.googleapis.com/maps/api/geocode/json?Client=gme-prismdb&sensor=false&address=";

function LoadSearchResults(form){	
console.log('1');
$("#network").val(null); // reset first

    var data = form.serialize();     
    var searchTerm = $("#address").val();
    
    // intercept here to determine if california
    GetDataNoForm(GEOCODE_SERVICE + searchTerm, function(response){
	
	if(response.results[0]){		
		var formatted_address = response.results[0].formatted_address;		
		$("#address").val(formatted_address);
		data = form.serialize(); 
		var address_components = response.results[0].address_components;		
		var state;
		
		// figure out the state
		for (var i=0;i<address_components.length;i++)
		{ 
			var address_component = address_components[i];
			var address_types = address_component.types;
			for (var it=0;it<address_types.length;it++)
			{ 
				var address_type = address_types[it];
				if(address_type == "administrative_area_level_1"){
					state = address_component.short_name;
					break;
				}
			}
			if(state) break; // no need to carry on looping if we have found the state
		}		
				
		if(state == "CA"){
			// is in CA						
			$("#CADialogLink").click();
			$('#CAdialog').dialog('option', 'position', 'center');
			$("#networkSubmit").click(function () { 
				var selected_network = $("#network-select").val();				
				if(selected_network.trim() != ""){
					$("#network").val(selected_network);					
					data = form.serialize();   
					GetData("search", data, FillSearchResults, ShowError);	
				}else{
					console.log("missing data");
				}
			});
		}else{
			// normal search
			GetData("search", data, FillSearchResults, ShowError);
		}	
	}else{
		// normal search
		GetData("search", data, FillSearchResults, ShowError);
	}
    
    }, ShowError);
}

function IsSpanish()
{
    return $(".languageLink").data("language") == "Español";
}

function FillSearchResults(data)
{
    //Update global variable with results
    searchResults = data;

    $("#totalResults").html(data.TotalResults);

    var container = $("#searchResults");
    var template = container.children(".result-template");
    var output = [template.outerHTML()]; //Ensure our template stays in place

    var j = 0;
    var results = data.Results;    

    for (var i = 0; i < results.length; i++)
    {
        template = template.clone(); //Create new copy
        template.removeClass("result-template hide"); //Remove template class

        //Update data values (have to set data-language attribute using attr method because data method reads the DOM initially then uses the cached result, so my template values was always being used)
        template.find(".result-name").attr("data-id",results[i].ProviderAddressID).attr("href","").html(results[i].ProviderName); //remove href for jQuery.mobile will cancel event
        template.find(".result-specialty").html(IsSpanish() ? results[i].SpecialtySpanish : results[i].Specialty).attr("data-language",(IsSpanish() ? results[i].Specialty : results[i].SpecialtySpanish));
        template.find(".result-streetAddress").html(results[i].StreetAddress);
        template.find(".result-cityStateZip").html(results[i].CityStateZip);
        template.find(".result-map").attr("href", mapUrl + results[i].StreetAddress + "," + results[i].CityStateZip);
        template.find(".result-phone").html(results[i].Phone);
        template.find(".result-tel").attr("href", "tel:" + results[i].Phone);
        template.find(".result-language").html(IsSpanish() ? results[i].LanguageSpanish : results[i].Language).attr("data-language",(IsSpanish() ? results[i].Language : results[i].LanguageSpanish));
        template.find(".result-distance").html(results[i].Distance);
	
        //Add to output ensuring not to overwrite our template
        output[i+1] = template.outerHTML();
    }
    container.html(output.join('')).trigger("create");

    $(".result-map").live("click", function (e) {
        e.preventDefault();
	var mapUrl = e.currentTarget.href;	
	window.open(mapUrl,'_blank', 'location=yes'); 	
    });

    FillNarrowFilters(data);

    CloseLoadingMsg();
    $.mobile.changePage($("#results"));
}

function FillNarrowFilters(data)
{
    if (data.Filters.length > 0)
    {
        $("a[href='#narrow']").show();
        var container = $("#narrowFilters");
        var elements = "<fieldset>";
        var filters = data.Filters;
        for (var i = 0; i < filters.length; i++)
        {
            elements += BuildNarrowFilter(filters[i]);
        }
        elements += "</fieldset>";

        container.html(elements);

        SetHiddenFields(data.Criteria);
        RefreshElements($("#narrowFilters"));
    }
    else
    {
        $("a[href='#narrow']").hide();
    }
}

function RefreshElements(container)
{
    container.find("div[data-role=collapsible]").collapsible({ theme: "c", refresh: true });
    container.find("input[type=checkbox]").checkboxradio().checkboxradio("refresh");
    container.find("input[type=button]").button().button("refresh");
    container.find("select").selectmenu().selectmenu("refresh");
}

function SetHiddenFields(criteria)
{
    $(".hidden-latitude").val(criteria.Latitude);
    $(".hidden-longitude").val(criteria.Longitude);
    $(".hidden-proximity").val(criteria.Proximity);
    $(".hidden-network").val(criteria.PPONational ? "-1" : criteria.NetworkString);
    $(".hidden-language").val(criteria.InitialLanguageString);
    $(".hidden-specialty").val(criteria.InitialSpecialtyString);
    $(".hidden-name").val(criteria.ProviderName);
}

function ClearHiddenFields()
{
    $(".hidden-latitude").val("");
    $(".hidden-longitude").val("");
    $(".hidden-proximity").val("");
    $(".hidden-network").val("");
    $(".hidden-language").val("");
    $(".hidden-specialty").val("");
    $(".hidden-name").val("");
    $(".city").val("");
    $(".state").val("").trigger("change");
    $(".county").val("");
    $(".zip").val("");
}

function BuildNarrowFilter(filter)
{
    var name = "filter" + filter.Name;
    var label = (filter.Label ? filter.Label : "");
    var data = filter.Data;

    var element = "";

    if (label.length > 0)
        element = "<div data-role=\"collapsible\" data-collapsed=\"true\" ><h3 data-language=\"" + (IsSpanish() ? label : filter.LabelSpanish) + "\">" + (IsSpanish() ? filter.LabelSpanish : label) + "</h3><p>";

    data = SortBy(data, (IsSpanish() ? "TextSpanish" : "Text"));

    for (var i = 0; i < data.length; i++)
        element += "<input name=\"" + name + "\" id=\"narrow-" + data[i].Value + "-" + name + "\" type=\"checkbox\" value=\"" + data[i].Value + "\"" + (data[i].Selected ? "checked=\"checked\"" : "") + " /><label for=\"narrow-" + data[i].Value + "-" + name + "\">" + (IsSpanish() ? data[i].TextSpanish : data[i].Text) + "</label>";

    if (label.length > 0)
        element += "</p></div>";
    return element;
}

function ClearFilterSelections()
{
    $("#narrowFilters input").removeAttr("checked");
}

function FindAdjacentProfile(next)
{
    var id = profile.ProviderAddressID;

    for (i = 0; i < searchResults.Results.length; i++)
    {
        if (searchResults.Results[i].ProviderAddressID == id)
        {
            if (next)
            {
                SetPreviousNextProfileVisibility(i + 1);
                return FillProfile(searchResults.Results[i + 1]);
            }
            else
            {
                SetPreviousNextProfileVisibility(i - 1);
                return FillProfile(searchResults.Results[i - 1]);
            }
        }
    }
}

function SetPreviousNextProfileVisibility(index)
{
    if (index > 0) //not first profile
        $(".previousProfile").fadeIn("fast");
    else
        $(".previousProfile").fadeOut("fast");

    if (index < searchResults.Results.length - 1) //not last profile
        $(".nextProfile").fadeIn("fast");
    else
        $(".nextProfile").fadeOut("fast");
}

function LoadProfile(id)
{
    //Load profile from search results
    if (id)
    {
        for (i = 0; i < searchResults.Results.length; i++)
        {
            if (searchResults.Results[i].ProviderAddressID == id)
            {
                SetPreviousNextProfileVisibility(i);
                return FillProfile(searchResults.Results[i]);
            }
        }

        //If we need to support deep linking do lookup if not found in results
        GetData("profile/" + id, null, FillProfile, ShowError);
    }
}

function FillProfile(data)
{
    //Update global variable with profile
    profile = data;

    $(".profile-name").html(data.ProviderName);
    $(".profile-specialty").html(IsSpanish() ? data.SpecialtySpanish : data.Specialty);
    $(".profile-specialty").data("language", (IsSpanish() ? data.Specialty : data.SpecialtySpanish));
    $(".profile-streetAddress").html(data.StreetAddress);
    $(".profile-cityStateZip").html(data.CityStateZip);
    $(".profile-map").attr("href", mapUrl + data.StreetAddress + "," + data.CityStateZip);
    $(".profile-map").live("click", function (e) {
        e.preventDefault();	
	window.open($(".profile-map").attr("href"), '_blank', 'location=yes');       
    });
    $(".profile-phone").html(data.Phone);
    $(".profile-tel").attr("href", "tel:" + data.Phone);
    $(".profile-language").html(IsSpanish() ? data.LanguageSpanish : data.Language);
    $(".profile-language").data("language", (IsSpanish() ? data.Language : data.LanguageSpanish));
    $(".profile-addToContact").data("id", data.ProviderAddressID);

    if (data.AcceptingNewPatients)
        $(".profile-acceptingNewPatients").hide("slow");
    else
        $(".profile-acceptingNewPatients").show("slow"); //not accepting message

    if (data.UniversityOfNebraska)
        $(".profile-universityOfNebraska").show("slow");
    else
        $(".profile-universityOfNebraska").hide("slow");

    if (data.OffersDiscounts)
        $(".profile-offersDiscounts").show("slow");
    else
        $(".profile-offersDiscounts").hide("slow");

    if (data.Preferred)
        $(".profile-preferred").show("slow");
    else
        $(".profile-preferred").hide("slow");

    if (data.OfficeHours != null && data.OfficeHours.length > 0)
    {
        if (typeof(data.OfficeHours) == "string")
            $(".profile-officeHours").html(data.OfficeHours);
        else
        {
            var list = "<ul>";
            for (var i = 0; i < data.OfficeHours.length; i++)
                list += "<li class=\"" + (i % 2 == 1 ? "ui-bar ui-bar-b" : "ui-bar ui-bar-c") + "\"><div data-language=\"" + (IsSpanish() ? data.OfficeHours[i].Weekday : data.OfficeHours[i].WeekdaySpanish) + "\">" + (IsSpanish() ? data.OfficeHours[i].WeekdaySpanish : data.OfficeHours[i].Weekday) + ":</div><div>" + data.OfficeHours[i].Hours + "</div></li>";

            list += "</ul>";
            $(".profile-officeHours").html(list);
        }
        $(".profile-collapsible-officeHours").show("slow");
    }
    else
        $(".profile-collapsible-officeHours").hide("slow");
	 //$(".profile-collapsible-officeHours").show("slow");

    if (data.AdditionalProviders.length > 0)
    {
        var list = "<ul>";
        for (var i = 0; i < data.AdditionalProviders.length; i++)
            list += "<li class=\"" + (i % 2 == 1 ? "ui-bar ui-bar-b" : "ui-bar ui-bar-c") + "\"><div>" + data.AdditionalProviders[i].ProviderName + "</div><div data-language=\"" + (IsSpanish() ? data.AdditionalProviders[i].Specialty : data.AdditionalProviders[i].SpecialtySpanish) + "\">" + (IsSpanish() ? data.AdditionalProviders[i].SpecialtySpanish : data.AdditionalProviders[i].Specialty) + "</div></li>";

        list += "</ul>";
        $(".profile-additionalProviders").html(list);
        $(".profile-collapsible-additionalProviders").show("slow");
    }
    else
        $(".profile-collapsible-additionalProviders").hide("slow");

    $.mobile.changePage($("#profile"));
}

function AddContact()
{
    if (!navigator.contacts) return;

    // Create a new contact
    var contact = navigator.contacts.create();

    // Set contact name
    contact.displayName = profile.ProviderName;
    contact.nickname = profile.ProviderName;
    var name = new ContactName();
    name.givenName = profile.FirstName;
    name.familyName = profile.LastName;
    contact.name = name;

    // Store contact Address
    var address = new ContactAddress();
    address.type = "work";
    address.streetAddress = profile.StreetAddress;
    address.locality = profile.City;
    address.region = profile.State;
    address.postalcode = profile.Zip;
    contact.addresses = [address];

    // Store contact phone numbers
    contact.phoneNumbers = [new ContactField('work', profile.Phone, false)];

    // Save the Contact
    contact.save(function () { alert("Contact successfully saved"); }, function (error) { alert("Unable to save contact (error code: " + error.code + ")"); });
}

(function ($)
{
    //Extension to wrap the current item so we get the item's full html. In addition it clones the item so you don't end up altering the actual item in the DOM.
    $.fn.outerHTML = function ()
    {
        return $(this).clone().wrap('<p>').parent().html();
    }
})(jQuery);

$(document).ready(function ()
{
	
	if(navigator.userAgent.match(/android/gi)){		
		$.mobile.defaultPageTransition = 'none';
		$.mobile.defaultDialogTransition = 'none';
		$.mobile.useFastClick = true;
	}else{		
		$.mobile.defaultPageTransition = 'slide';		
	}
	

    SetDataServer();
    SetMapUrl();

    LoadNetworks();
    LoadSpecialties();
    LoadLanguages();

    $("#searchForm, #narrowForm").submit(function () { LoadSearchResults($(this)); return false; });
    $("#emailResultsForm").submit(function () { SendPDFEmail($(this)); return false; });
    $("#searchResults a[data-id]").live("click", function () { LoadProfile($(this).data("id")); });
    $("#clearFilterButton").click(function () { ClearFilterSelections(); LoadSearchResults($("#narrowForm")); });
    $(".nextProfile").click(function () { FindAdjacentProfile(true); });
    $(".previousProfile").click(function () { FindAdjacentProfile(false); });
    $(".languageLink").click(function ()
    {
        Translate();
        LoadSpecialties();
        LoadLanguages();
        if (searchResults)
            FillNarrowFilters(searchResults);

        //Refresh controls so jquery mobile updates the elements it creates
        $("select").selectmenu().selectmenu("refresh");
        return false; 
     });
    $(".profile-addToContact").click(function () { AddContact(); return false; });
});

