﻿/// <reference path="http://ajax.microsoft.com/ajax/jQuery/jquery-1.8.2-vsdoc.js" />

(function ($)
{
    //Extension to translate elements with data-language attributes
    $.fn.toggleLanguage = function ()
    {
        var newText = $(this).data("language");
        if (newText)
        {
            var mobileSpan = $(this).find(".ui-btn-text");
            if (mobileSpan.length > 0) //jQuery mobile overridden elements
            {
                var first = mobileSpan.first();
                $(this).data("language", first.html());
                first.html(newText);
            }
            else if ($(this).is("input"))
            {
                if ($(this).attr("placeholder") != null) //Inputs with placeholder attribute
                {
                    $(this).data("language", $(this).attr("placeholder")); //Put old text into data-language attribute
                    $(this).attr("placeholder", newText); //Set placeholder to new text
                }
                else if ($(this).attr("type") == "button" || $(this).attr("type") == "submit") //Buttons
                {
                    $(this).data("language", $(this).val());
                    $(this).val(newText);
                    $(this).button().button("refresh");
                }
            }
            else //Container elements 
            {
                $(this).data("language", $(this).html()); //Put old text into data-language attribute
                $(this).html(newText); //Set new text
            }
        }
    }
})(jQuery);

function Translate()
{
    $("*[data-language]*").each(function ()
    {
        $(this).toggleLanguage();
    });
}
