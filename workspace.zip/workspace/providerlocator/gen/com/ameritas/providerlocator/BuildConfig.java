/** Automatically generated file. DO NOT MODIFY */
package com.ameritas.providerlocator;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}